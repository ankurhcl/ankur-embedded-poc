# Zephyr Basic Apps

Collection of minimal Zephyr RTOS applications for embedded board testing and bring-up.

## Apps

- `gpio_toggle/` – Blinks an LED using GPIO
- `uart_echo/` – Echoes characters received on UART

## Build

```bash
west build -b <board> gpio_toggle
west build -b <board> uart_echo
```
