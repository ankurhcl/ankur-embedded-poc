#include <zephyr/kernel.h>
#include <zephyr/drivers/uart.h>
#include <string.h>

#define UART_NODE DT_LABEL(DT_CHOSEN(zephyr_console))

void main(void) {
    const struct device *uart = device_get_binding(UART_NODE);
    if (!uart) return;

    uint8_t c;
    while (1) {
        uart_poll_in(uart, &c);
        uart_poll_out(uart, c);
    }
}
