#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>

#define GPIO_NODE DT_ALIAS(led0)
#define GPIO_FLAGS GPIO_OUTPUT_ACTIVE

void main(void) {
    const struct device *dev = DEVICE_DT_GET(GPIO_NODE);
    if (!device_is_ready(dev)) return;

    gpio_pin_configure(dev, DT_GPIO_PIN(GPIO_NODE, gpios), GPIO_OUTPUT_ACTIVE);

    while (1) {
        gpio_pin_toggle(dev, DT_GPIO_PIN(GPIO_NODE, gpios));
        k_sleep(K_MSEC(500));
    }
}
