# OpenWRT Board Bring-Up Demo

Minimal bring-up template for OpenWRT custom boards. Includes:
- Board detection script
- Default kernel config
- UCI-based initial setup
- Init script for LED setup
- Device Tree Overlay

Tested on embedded boards using RAM boot or TFTP.

---

## Usage

Copy contents into an OpenWRT buildroot `target/` directory or use these for creating a custom feed.

---

## Author

Ankur Rastogi  
📧 arlinuxiot2020@gmail.com  
🔗 https://github.com/ankur-bsp-dev

