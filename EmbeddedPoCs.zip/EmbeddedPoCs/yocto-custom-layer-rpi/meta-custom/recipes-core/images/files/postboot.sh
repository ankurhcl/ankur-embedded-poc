#!/bin/sh
echo "Custom postboot script running..." > /dev/kmsg

