#include "gpio_hal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s <gpio> <in|out> [value]\\n", argv[0]);
        return 1;
    }

    int gpio = atoi(argv[1]);
    char *dir = argv[2];

    gpio_export(gpio);
    gpio_set_dir(gpio, strcmp(dir, "out") == 0);

    if (strcmp(dir, "out") == 0 && argc == 4) {
        int value = atoi(argv[3]);
        gpio_set_value(gpio, value);
        printf("GPIO %d set to %d\\n", gpio, value);
    } else if (strcmp(dir, "in") == 0) {
        int value = gpio_get_value(gpio);
        printf("GPIO %d reads %d\\n", gpio, value);
    }

    gpio_unexport(gpio);
    return 0;
}

