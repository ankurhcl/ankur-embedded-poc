
---

### `src/gpio_hal.h`
```c
#ifndef GPIO_HAL_H
#define GPIO_HAL_H

int gpio_export(int gpio);
int gpio_unexport(int gpio);
int gpio_set_dir(int gpio, int is_output);
int gpio_set_value(int gpio, int value);
int gpio_get_value(int gpio);

#endif

