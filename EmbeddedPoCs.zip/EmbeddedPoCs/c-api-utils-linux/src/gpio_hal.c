#include "gpio_hal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

int gpio_export(int gpio) {
    char buffer[64];
    int fd = open("/sys/class/gpio/export", O_WRONLY);
    if (fd < 0) return -1;
    snprintf(buffer, sizeof(buffer), "%d", gpio);
    write(fd, buffer, strlen(buffer));
    close(fd);
    return 0;
}

int gpio_unexport(int gpio) {
    char buffer[64];
    int fd = open("/sys/class/gpio/unexport", O_WRONLY);
    if (fd < 0) return -1;
    snprintf(buffer, sizeof(buffer), "%d", gpio);
    write(fd, buffer, strlen(buffer));
    close(fd);
    return 0;
}

int gpio_set_dir(int gpio, int is_output) {
    char path[64];
    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/direction", gpio);
    int fd = open(path, O_WRONLY);
    if (fd < 0) return -1;
    if (is_output)
        write(fd, "out", 3);
    else
        write(fd, "in", 2);
    close(fd);
    return 0;
}

int gpio_set_value(int gpio, int value) {
    char path[64];
    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", gpio);
    int fd = open(path, O_WRONLY);
    if (fd < 0) return -1;
    dprintf(fd, "%d", value);
    close(fd);
    return 0;
}

int gpio_get_value(int gpio) {
    char path[64], value_str[3];
    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", gpio);
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    read(fd, value_str, sizeof(value_str));
    close(fd);
    return atoi(value_str);
}

