# Linux GPIO HAL and CLI Utility in C

This project implements a modular and extensible GPIO HAL (Hardware Abstraction Layer) in C for Linux embedded systems using the `/sys/class/gpio` interface. It includes a basic test utility for toggling GPIOs from user space.

---

## ✅ Features

- Export / unexport GPIOs
- Set GPIO direction (input/output)
- Read and write GPIO values
- Designed for embedded Linux user space (non-kernel)

---

## 📁 Files

- `gpio_hal.h`: Header for GPIO HAL API
- `gpio_hal.c`: Implementation of HAL functions
- `main.c`: Sample utility demonstrating HAL usage
- `Makefile`: Build everything into a single binary

---

## 🔧 Build

```bash
make

