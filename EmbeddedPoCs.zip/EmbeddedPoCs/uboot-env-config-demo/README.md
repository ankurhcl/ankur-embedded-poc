# U-Boot Environment + FIT Image Demo

Shows:
- Secure boot script
- FIT image loading
- mkimage script generation

Build FIT:
```bash
mkimage -f fitImage.its fitImage

Generate boot.scr:
mkimage -A arm -T script -C none -n "Boot Script" -d boot.cmd boot.scr


