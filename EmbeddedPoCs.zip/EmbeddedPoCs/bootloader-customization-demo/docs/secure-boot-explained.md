# Secure Boot with U-Boot (High Level)

This document explains a simplified secure boot flow for U-Boot using FIT images and RSA signatures.

## Flow
1. Produce a FIT image (`fitImage`) that contains kernel and FDT (and optionally ramdisk).
2. Sign the FIT image using your private key to create a signature node (or use mkimage -k).
3. Install the public key(s) in U-Boot (or embed into a trusted area).
4. U-Boot loads the FIT into memory and verifies the signature using the public key.
5. If verification succeeds, U-Boot boots the kernel defined in FIT. If not, it halts or boots a fallback.

## Tools
- `mkimage` (from `u-boot-tools`) to assemble FIT and sign
- `openssl` to create key pairs
- U-Boot patches sometimes needed to enable `CONFIG_FIT_SIGNATURE` and RSA support

## Notes
- Keep private keys safe (hardware HSM or restricted access in CI).
- For production, use hardware-backed keys where possible.

