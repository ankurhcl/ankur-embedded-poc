#!/bin/bash
# mkboot.sh -- generate boot.scr and fitImage (demo)
# Requires: u-boot-tools (mkimage)

set -e

# Paths
BOOT_CMD="boot/boot.cmd"
BOOT_SCR="boot.scr"
FIT_SRC="fit/fitImage.its"
FIT_OUT="fitImage"
PUBKEY="keys/pubkey.pem"

# Create boot.scr
if [ -f "$BOOT_CMD" ]; then
  echo "[*] Generating ${BOOT_SCR} from ${BOOT_CMD}"
  mkimage -A arm -T script -C none -n "Boot Script" -d "${BOOT_CMD}" "${BOOT_SCR}"
else
  echo "[!] ${BOOT_CMD} not found"
  exit 1
fi

# Create unsigned FIT (if fit source exists)
if [ -f "$FIT_SRC" ]; then
  echo "[*] Generating unsigned FIT image ${FIT_OUT} from ${FIT_SRC}"
  mkimage -f "${FIT_SRC}" "${FIT_OUT}"
  echo "[*] FIT image created: ${FIT_OUT}"
else
  echo "[!] ${FIT_SRC} not found; skipping FIT creation"
fi

# Note on signing:
if [ -f "$PUBKEY" ]; then
  echo "[*] Public key present at ${PUBKEY} (placeholder)."
  echo "    For production, sign the FIT using mkimage -k <private-key> -r <fitImage.its> ..."
else
  echo "[!] Public key not found at ${PUBKEY}. Use your own keys for verified boot."
fi

echo "[*] Done."

