# Bootloader Customization Demo (U-Boot)

**Purpose:** Demonstrate a safe, shareable proof-of-concept for U-Boot customization:
- U-Boot boot script (`boot.cmd` → `boot.scr`)
- Building a FIT image (`fit/fitImage.its`)
- Example script to create `boot.scr` and `fitImage` (`boot/mkboot.sh`)
- Example public key placeholder (`keys/pubkey.pem`) for FIT signature verification
- Example U-Boot patch to enable FIT & secure boot options
- Sample `printenv` and sample boot log

**Not for production:** this POC uses placeholder keys and simplified examples. Replace keys and addresses for your hardware.

## Quick demo steps (developer-friendly)
1. Install `u-boot-tools` (for `mkimage`).
2. Edit `fit/fitImage.its` to point to your kernel/zImage/dtb if you have them.
3. (Optional) Replace `keys/pubkey.pem` with your RSA public key in PEM format.
4. Run:
   ```bash
   chmod +x boot/mkboot.sh
   ./boot/mkboot.sh

