#!/bin/bash
echo "[USB INFO]"
lsusb
