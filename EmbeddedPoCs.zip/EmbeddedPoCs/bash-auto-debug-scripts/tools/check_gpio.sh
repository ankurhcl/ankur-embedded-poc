#!/bin/bash
echo "[GPIO CHECK]"
for gpio in /sys/class/gpio/gpio*; do
    echo "$(basename $gpio): $(cat $gpio/value 2>/dev/null)"
done
