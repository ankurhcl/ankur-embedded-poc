#!/bin/bash
echo "[ETHERNET DIAGNOSTICS]"
ip addr show
ethtool eth0 2>/dev/null || echo "ethtool not installed or eth0 not found"
