#!/bin/bash
echo "[I2C SCAN]"
for bus in /dev/i2c-*; do
    echo "Bus: $bus"
    i2cdetect -y "${bus##*/}"
done
