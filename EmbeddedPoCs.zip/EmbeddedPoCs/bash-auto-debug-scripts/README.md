# Bash Auto Debug Scripts

A collection of Bash scripts to automate hardware and interface diagnostics on embedded Linux systems.

## Tools Included

- `check_gpio.sh`: Reads values from all exported GPIOs
- `scan_i2c.sh`: Scans all available I2C buses using `i2cdetect`
- `usb_info.sh`: Lists all USB devices using `lsusb`
- `eth_diag.sh`: Displays Ethernet interface and PHY diagnostics

## Usage

```bash
chmod +x tools/*.sh
./tools/check_gpio.sh
./tools/scan_i2c.sh
./tools/usb_info.sh
./tools/eth_diag.sh
```

## Requirements

- `i2c-tools`, `usbutils`, `ethtool` (optional) depending on script

## Author

Ankur Rastogi – arlinuxiot2020@gmail.com
