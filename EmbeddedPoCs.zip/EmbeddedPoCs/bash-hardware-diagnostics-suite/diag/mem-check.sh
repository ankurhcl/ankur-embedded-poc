#!/bin/bash
echo "[MEMORY DIAGNOSTICS]"
echo "---------------------"
free -h
