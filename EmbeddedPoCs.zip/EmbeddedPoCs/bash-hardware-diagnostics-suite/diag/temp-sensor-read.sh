#!/bin/bash
echo "[TEMPERATURE SENSOR READOUT]"
echo "-----------------------------"

temp_file=$(find /sys/class/thermal/thermal_zone*/temp | head -n1)

if [[ -f "$temp_file" ]]; then
  temp=$(cat $temp_file)
  echo "CPU Temp: $((temp / 1000))°C"
else
  echo "No temperature sensor found."
fi
