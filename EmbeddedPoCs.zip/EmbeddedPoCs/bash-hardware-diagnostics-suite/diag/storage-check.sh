#!/bin/bash
echo "[STORAGE DIAGNOSTICS]"
echo "----------------------"
lsblk
echo
echo "[Testing read performance on rootfs]"
dd if=/dev/zero of=tempfile bs=1M count=100 conv=fdatasync,notrunc status=progress
rm -f tempfile
