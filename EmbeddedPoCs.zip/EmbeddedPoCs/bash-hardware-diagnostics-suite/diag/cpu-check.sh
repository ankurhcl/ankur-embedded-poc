#!/bin/bash
echo "[CPU DIAGNOSTICS]"
echo "------------------"
echo "Model: $(grep 'model name' /proc/cpuinfo | uniq | cut -d ':' -f2)"
echo "Cores: $(nproc)"
echo "Load:  $(uptime | awk -F'load average:' '{ print $2 }')"
