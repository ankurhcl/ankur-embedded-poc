#!/bin/bash
# TCP port checker - Ankur Rastogi

HOST=$1
if [ -z "$HOST" ]; then
    echo "Usage: $0 <ip-address>"
    exit 1
fi

echo "[*] Scanning open TCP ports on $HOST"
for PORT in {20..1024}; do
  (echo > /dev/tcp/$HOST/$PORT) >/dev/null 2>&1 && echo "Open Port: $PORT"
done

