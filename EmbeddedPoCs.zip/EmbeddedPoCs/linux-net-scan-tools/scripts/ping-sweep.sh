#!/bin/bash
# Ping sweep script - Ankur Rastogi

NET=$1
if [ -z "$NET" ]; then
    echo "Usage: $0 <subnet-prefix> (e.g. 192.168.1)"
    exit 1
fi

echo "[*] Scanning subnet: $NET.0/24"
for i in $(seq 1 254); do
  ping -c 1 -W 1 "$NET.$i" > /dev/null && echo "[+] Host $NET.$i is UP" &
done
wait

