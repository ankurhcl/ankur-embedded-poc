// interface-monitor.c – Monitor live network interface stats
// Author: Ankur Rastogi

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <interface>\n", argv[0]);
        return 1;
    }

    char cmd[128];
    snprintf(cmd, sizeof(cmd), "watch -n 1 ifconfig %s", argv[1]);
    printf("Launching interface monitor for %s...\n", argv[1]);
    return system(cmd);
}

