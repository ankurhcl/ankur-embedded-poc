# Linux Network Scanner & Interface Tools (Bash + C)

This repository contains lightweight and production-safe tools for embedded and Linux-based systems to perform basic network scanning and diagnostics. Ideal for factory-line diagnostics, IoT gateways, or edge Linux boxes.

---

## 📦 Tools Included

### ✅ 1. `ping-sweep.sh`
Performs a fast ping scan on a given subnet (e.g., `192.168.1.x`) to identify live hosts.

### ✅ 2. `tcp-port-checker.sh`
Performs a basic TCP port scan (20–1024) on a specific IP to identify open ports.

### ✅ 3. `interface-monitor.c`
C-based utility to display live stats of a given network interface using `ifconfig` under `watch`.

---

## 🛠️ Usage

```bash
# 1. Run subnet sweep
bash scripts/ping-sweep.sh 192.168.1

# 2. Run TCP port check
bash scripts/tcp-port-checker.sh 192.168.1.10

# 3. Compile and run network interface monitor
gcc scripts/interface-monitor.c -o scripts/ifacemon
sudo ./scripts/ifacemon eth0

