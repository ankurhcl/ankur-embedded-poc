#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd = open("/dev/simple_char", O_RDWR);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    write(fd, "Hello BSP World!", 17);
    lseek(fd, 0, SEEK_SET);
    char buffer[128] = {0};
    read(fd, buffer, sizeof(buffer));
    printf("Read: %s\n", buffer);
    close(fd);
    return 0;
}

