#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#define DEVICE_NAME "simple_char"
static int major;
static char message[256] = {0};

static int dev_open(struct inode *, struct file *) { return 0; }
static int dev_release(struct inode *, struct file *) { return 0; }

static ssize_t dev_read(struct file *filep, char *buffer, size_t len, loff_t *offset) {
    return simple_read_from_buffer(buffer, len, offset, message, strlen(message));
}

static ssize_t dev_write(struct file *filep, const char *buffer, size_t len, loff_t *offset) {
    return simple_write_to_buffer(message, sizeof(message), offset, buffer, len);
}

static struct file_operations fops = {
    .open = dev_open,
    .read = dev_read,
    .write = dev_write,
    .release = dev_release,
};

static int __init char_init(void) {
    major = register_chrdev(0, DEVICE_NAME, &fops);
    printk(KERN_INFO "SimpleChar: registered with major number %d\n", major);
    return 0;
}

static void __exit char_exit(void) {
    unregister_chrdev(major, DEVICE_NAME);
    printk(KERN_INFO "SimpleChar: unregistered\n");
}

module_init(char_init);
module_exit(char_exit);
MODULE_LICENSE("GPL");
